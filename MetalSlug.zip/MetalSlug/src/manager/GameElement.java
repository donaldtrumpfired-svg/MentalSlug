//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package manager;

public enum GameElement {
    MAPS,
    PLANE,
    PLAY,
    ENEMY,
    BOSS,
    PLAYFILE,//玩家子弹攻击
    ENEMYFILE,//敌人子弹攻击
    WEAPON,//玩家武器
    TOOL,//道具
    HOSTAGE,//人质
    DIE,//死亡
    PLANEFILE;
    private GameElement() {
    }
}
